import os
os.system("python3 -m rasa_core.run -d models/dialogue -u models/nlu/default/horoscopebot --endpoint endpoints.yml")
